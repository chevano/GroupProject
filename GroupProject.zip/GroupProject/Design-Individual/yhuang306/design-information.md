1) I added to the design a class *groceryList* with attributes **listName**,  **items** and **itemType**. Class *groceryList* has a **listName** and bunch of **items** to be added to the list. This class could **addItem** by typing the name or choose from the *heierarchicalList*. You could delete item from the list, change the quantity of the item, checkoff the item, and clear the checkoff.
2) The application must contain a database (DB) of items and correspinding item types. To realize this requirement, I added to the design a class *items* with attributes **itemName** and **itemType**. Class *items* contains the list of items, like a library. You could search the item you want, and add new items that are not in the list, then put them into the appropriate itemType.
3) I added a Class *hierarchicalList* with attributes **itemName** and **itemType**. You could search through this class to find the item you want.
4) Item could be search by name and could add new item to it.
5) I added a method saveAuto to the Class *list*, so any change will be save right away.
6) I created a method in the groceryList to check off the items.
7) A clearCheckOffMark added to the groceryList also to clear all the checkoff marks.
8) Not considered, because it does not affect the design directly.
9) Not considered, because it does not affect the design directly.
10) I added a class of *list* with attribute **listName**. You could create as many list as you want, rename them, select or delete the list you want.
11) The User Interface (UI) must be intuitive and responsive. Not considered because it does not affect the design directly.


Copyright [Yuhuan Huang] &copy; All Rights Reserved